---
name: Data update
about: Some data need an update? Please specify the changes
title: Data update
labels: update
assignees: ''
---

### Data changes

<!-- please describe required changes to be made, as strict as possible -->

### Links & sources

Here is a valid source for this change:

<!-- urls -->
